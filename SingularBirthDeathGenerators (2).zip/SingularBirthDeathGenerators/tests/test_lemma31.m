% TEST_LEMMA31  Verify Lemma 3.1: sigma_max(Qc) <= ||Qt||_2 / 2.
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators

function test_lemma31()
    fprintf('Testing Lemma 3.1: sigma_max(Qc) <= ||Qt||_2 / 2 ...\n');
    n_vals = [50, 100, 200, 500, 1000];
    rho_vals = [0.5, 0.9, 0.99, 0.999, 0.9999];
    mu = 1;
    all_pass = true;

    for n = n_vals
        for rho = rho_vals
            [Q, ~, pi_ex] = mmn_generator(n, rho*mu, mu);
            [Qt, D, ~]    = symmetrise_generator(full(Q), pi_ex);
            [R, P, ~]     = build_restriction(n);
            Qc            = galerkin_coarsen(Qt, R, P);

            bound   = norm(Qt, 2) / 2;
            sig_max = norm(Qc, 2);
            pass    = sig_max <= bound + 1e-10 * bound;
            if ~pass, all_pass = false; end
        end
    end

    % Also test on random symmetric tridiagonal matrices
    rng(0);
    for n = [50, 200, 500]
        d = randn(n,1); od = randn(n-1,1);
        Qt_rand = diag(od,-1) + diag(d,0) + diag(od,1);
        [R, P, ~] = build_restriction(n);
        Qc = galerkin_coarsen(Qt_rand, R, P);
        bound = norm(Qt_rand,2)/2;
        sig_max = norm(Qc,2);
        pass = sig_max <= bound + 1e-10*bound;
        if ~pass, all_pass = false; end
    end

    if all_pass
        fprintf('PASS: sigma_max(Qc) <= ||Qt||_2/2 in all cases.\n\n');
    else
        error('FAIL: Lemma 3.1 violated.');
    end
end

test_lemma31();
