% RUN_ALL_TESTS  Execute the full unit-test suite.
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Tests correspond to the theoretical results of the paper:
%     test_restriction_identity  -- equation (16): R*R' = (1/2)*I
%     test_lemma31               -- Lemma 3.1: sigma_max(Qc) <= ||Qt||_2/2
%     test_theorem32             -- Theorem 3.2: kappa_2(Q'_c) <= sigma_max/tau
%     test_theorem38             -- Theorem 3.8: minimal perturbation equality
%     test_galerkin_lumping      -- Theorem 2.5: Galerkin == Kemeny-Snell

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

fprintf('================================================\n');
fprintf('  Unit test suite for singular BD-generator framework\n');
fprintf('================================================\n\n');

t_start = tic;
failed = {};

test_fns = {
    'test_restriction_identity';
    'test_lemma31';
    'test_theorem32';
    'test_theorem38';
    'test_galerkin_lumping';
};

for k = 1:length(test_fns)
    fname = test_fns{k};
    fprintf('--- %s ---\n', fname);
    try
        run(fullfile(fileparts(mfilename('fullpath')), [fname '.m']));
    catch ME
        fprintf('FAIL: %s\n  %s\n', fname, ME.message);
        failed{end+1} = fname; %#ok<AGROW>
    end
end

fprintf('\n================================================\n');
if isempty(failed)
    fprintf('All %d tests PASSED in %.2f s.\n', length(test_fns), toc(t_start));
else
    fprintf('%d / %d tests FAILED: %s\n', length(failed), length(test_fns), ...
        strjoin(failed, ', '));
end
fprintf('================================================\n');
