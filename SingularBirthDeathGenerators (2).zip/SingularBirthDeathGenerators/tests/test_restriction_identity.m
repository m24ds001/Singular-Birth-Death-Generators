% TEST_RESTRICTION_IDENTITY  Verify R*R' = (1/2)*I_nc (equation 16).
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Tests the identity for even n, odd n, and several chain lengths.
%   This identity is the algebraic engine of the entire implication chain (6).

function test_restriction_identity()
    tol = 1e-13;
    n_vals = [10, 50, 100, 101, 500, 501, 1000];
    all_pass = true;

    fprintf('Testing R*R^T = (1/2)*I_nc ...\n');
    for n = n_vals
        [R, ~, nc] = build_restriction(n);
        err = norm(R*R' - 0.5*speye(nc), 'fro');
        pass = err < tol;
        if ~pass, all_pass = false; end
        fprintf('  n=%4d (nc=%3d): ||RR^T - 0.5*I||_F = %.2e  [%s]\n', ...
            n, nc, err, status(pass));
    end

    if all_pass
        fprintf('PASS: R*R^T = (1/2)*I holds for all tested n.\n\n');
    else
        error('FAIL: R*R^T identity violated for some n.');
    end
end

function s = status(pass)
    if pass, s = 'PASS'; else, s = 'FAIL'; end
end

test_restriction_identity();
