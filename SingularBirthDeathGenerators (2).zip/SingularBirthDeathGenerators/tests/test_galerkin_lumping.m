% TEST_GALERKIN_LUMPING  Verify Theorem 2.5: Galerkin == Kemeny-Snell lumping
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%   for uniform-rate birth-death chains.

function test_galerkin_lumping()
    fprintf('Testing Theorem 2.5: Galerkin coarsening == Kemeny-Snell lumping ...\n');
    mu = 1;
    test_cases = {100, 0.5; 200, 0.9; 500, 0.99; 1000, 0.999};
    tol = 1e-12;
    all_pass = true;

    for tc = 1:size(test_cases,1)
        n   = test_cases{tc,1};
        rho = test_cases{tc,2};
        lambda = rho * mu;

        [Q, ~, pi_ex] = mmn_generator(n, lambda, mu);
        [Qt, D, ~]    = symmetrise_generator(full(Q), pi_ex);
        [R, P, nc]    = build_restriction(n);

        % Galerkin coarse operator
        Qc_galerkin = galerkin_coarsen(Qt, R, P);

        % Kemeny-Snell lumped generator (equation 20):
        % Q_hat_{k,l} = sum_{j in C_l} Q_{i,j} for i in C_k (any representative)
        Qc_ks = zeros(nc);
        for k = 1:nc
            i_rep = 2*k - 1;   % representative state of class k
            if i_rep > n, break; end
            for l = 1:nc
                j_states = [2*l-1, 2*l];
                j_states = j_states(j_states <= n);
                % Use symmetrised Q for the comparison (Theorem 2.5 is stated for Qt)
                Qc_ks(k,l) = sum(Qt(i_rep, j_states));
            end
        end

        err = norm(Qc_galerkin - Qc_ks, 'fro') / (norm(Qc_ks,'fro') + eps);
        % Under uniform rates the Galerkin and KS operators should agree
        % up to a scalar factor (1/2) absorbed by the averaging in R; see
        % Theorem 2.5 proof.  Here we compare entrywise after normalisation.
        pass = err < tol * max(1, n);
        if ~pass, all_pass = false; end
        fprintf('  n=%4d, rho=%.4f: ||Qc_Galerkin - Qc_KS||_F/||Qc_KS||_F = %.2e  [%s]\n', ...
            n, rho, err, status(pass));
    end

    if all_pass
        fprintf('PASS: Galerkin == Kemeny-Snell (Theorem 2.5) for all tested cases.\n\n');
    else
        error('FAIL: Galerkin-Lumping equivalence violated.');
    end
end

function s = status(pass)
    if pass, s = 'PASS'; else, s = 'FAIL'; end
end

test_galerkin_lumping();
