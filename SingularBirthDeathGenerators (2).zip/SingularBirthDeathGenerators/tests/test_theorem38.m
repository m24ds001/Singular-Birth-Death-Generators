% TEST_THEOREM38  Verify Theorem 3.8: minimal perturbation equality.
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%   ||Qc - Q'_c||_2 = max_{i: |lambda_i|<tau} (tau - |lambda_i|)
%   Reproduces Table 20.

function test_theorem38()
    fprintf('Testing Theorem 3.8: minimal perturbation equality (Table 20) ...\n');
    fprintf('%-10s  %-12s  %-24s  %-24s  %-14s\n', ...
        'delta_diag','kappa_2(A)','Computed ||Qc-Q_c_rep||_2','Theoretical','Rel. diff.');
    fprintf('%s\n', repmat('-',1,90));

    n = 100;
    delta_vals = [1e-4, 1e-8, 1e-12, 0];
    [R, P, ~] = build_restriction(n);
    tol_check = 1e-12;
    all_pass = true;

    for d_diag = delta_vals
        if d_diag == 0
            A = full(spdiags(ones(n,1)*[1,0,1],[-1,0,1],n,n));
        else
            A = full(spdiags(ones(n,1)*[1,d_diag,1],[-1,0,1],n,n));
        end

        Qc = galerkin_coarsen(A, R, P);
        tau = 0.1 * norm(Qc, 2);
        lam = eig(Qc);
        [Qc_rep, ~, ~, ~] = spectral_repair(Qc, tau);

        computed   = norm(Qc - Qc_rep, 2);
        theoretical = max([0; tau - abs(lam(abs(lam) < tau))]);

        rel_diff = abs(computed - theoretical) / (theoretical + eps);
        pass = rel_diff < 1e-12;
        if ~pass, all_pass = false; end

        kappa_A = cond(A);
        fprintf('%-10.0e  %-12.2e  %-24.6e  %-24.6e  %-14.2e  [%s]\n', ...
            d_diag, kappa_A, computed, theoretical, rel_diff, status(pass));
    end

    if all_pass
        fprintf('PASS: Theorem 3.8 verified; relative differences < 1e-12.\n\n');
    else
        error('FAIL: Theorem 3.8 perturbation equality violated.');
    end
end

function s = status(pass)
    if pass, s = 'PASS'; else, s = 'FAIL'; end
end

test_theorem38();
