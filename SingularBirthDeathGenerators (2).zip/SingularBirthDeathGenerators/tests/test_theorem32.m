% TEST_THEOREM32  Verify Theorem 3.2: kappa_2(Q'_c) <= sigma_max(Qc) / tau.
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators

function test_theorem32()
    fprintf('Testing Theorem 3.2: kappa_2(Q_c_rep) <= sigma_max(Qc)/tau ...\n');
    rng(1);
    n_vals  = [20, 50, 100, 200];
    tau_rel = [0.01, 0.05, 0.1, 0.5];
    all_pass = true;

    for n = n_vals
        d = -abs(randn(n,1)) - 0.1;
        od = abs(randn(n-1,1));
        Qc_sym = diag(od,-1) + diag(d,0) + diag(od,1);  % indefinite symmetric

        for tr = tau_rel
            sig_max = norm(Qc_sym, 2);
            tau = tr * sig_max;
            [~, ~, ~, kappa] = spectral_repair(Qc_sym, tau);
            bound = sig_max / tau;
            pass  = kappa <= bound + 1e-8 * bound;
            if ~pass
                all_pass = false;
                fprintf('  FAIL n=%d tr=%.2e kappa=%.4e bound=%.4e\n', n, tr, kappa, bound);
            end
        end
    end

    if all_pass
        fprintf('PASS: kappa_2(Q_c_rep) <= sigma_max(Qc)/tau in all cases.\n\n');
    else
        error('FAIL: Theorem 3.2 violated.');
    end
end

test_theorem32();
