% GENERATE_FIG3  Figure 3: PCG iteration count vs n (Strategy A).
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Reproduces Figure 3: count stabilises at 4-5 for all n >= 100;
%   compared to O(sqrt(kappa_2(A))) growth for unpreconditioned CG.

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

n_vals  = [100, 200, 500, 1000, 2000, 5000, 10000];
d_diag  = 1e-8;
n_runs  = 20;
rng(0);

iter_mean = zeros(length(n_vals),1);
iter_min  = zeros(length(n_vals),1);
iter_max  = zeros(length(n_vals),1);
kappa_cg  = zeros(length(n_vals),1);

for ni = 1:length(n_vals)
    n = n_vals(ni);
    A = full(spdiags(ones(n,1)*[1, d_diag, 1],[-1,0,1],n,n));
    [R, P, ~] = build_restriction(n);
    Qc  = galerkin_coarsen(A, R, P);
    tau = 0.1 * norm(Qc,2);
    [Qc_rep, ~, ~, ~] = spectral_repair(Qc, tau);

    iters_r = zeros(n_runs,1);
    for r = 1:n_runs
        b_rhs = randn(n,1);
        [~, iter_r, ~] = pcg_multiscale(A, b_rhs, Qc_rep, R, P, ...
            'tol', 1e-12, 'maxit', 100);
        iters_r(r) = iter_r;
    end
    iter_mean(ni) = mean(iters_r);
    iter_min(ni)  = min(iters_r);
    iter_max(ni)  = max(iters_r);
    kappa_cg(ni)  = cond(A);
end

fig = figure('Name','Fig3_iters_vs_n','Position',[100,100,700,450]);
hold on; box on; grid on;

% Proposed method with error bars
errorbar(n_vals, iter_mean, iter_mean - iter_min, iter_max - iter_mean, ...
    'b-o','LineWidth',1.8,'MarkerSize',7,'DisplayName','Strategy A (proposed)');

% Unpreconditioned CG upper bound: O(sqrt(kappa))
cg_bound = sqrt(kappa_cg) * 3;    % proportionality constant for illustration
loglog(n_vals, cg_bound, 'r--', 'LineWidth', 1.4, 'DisplayName', 'O(\sqrt{\kappa_2(A)}) unprecond. CG');

% Theoretical bound k < 9
yline(9, 'k:', 'Bound k < 9 (Cor. 3.5)', 'LineWidth', 1.2, ...
    'LabelHorizontalAlignment','left','FontSize',9);

set(gca, 'XScale', 'log', 'YScale', 'log', 'FontSize', 11);
xlabel('Problem size n', 'FontSize', 12);
ylabel('PCG iteration count', 'FontSize', 12);
title(sprintf('PCG iterations vs n, \\delta_{diag} = %.0e, Strategy A', d_diag), 'FontSize', 11);
legend('Location','northwest','FontSize',10);
xlim([80, 15000]); ylim([0.8, max(cg_bound)*1.2]);
set(gcf,'Color','w');

saveas(fig, fullfile(fileparts(mfilename('fullpath')),'fig3_iters_vs_n.pdf'));
fprintf('Figure 3 saved to fig3_iters_vs_n.pdf\n');
