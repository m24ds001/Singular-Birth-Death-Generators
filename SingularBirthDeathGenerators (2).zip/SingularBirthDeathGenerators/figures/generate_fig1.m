% GENERATE_FIG1  Figure 1: Spectral condition number vs traffic intensity.
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Plots kappa_2(Q) versus rho (log-log scale) for n in {100, 500, 1000}.
%   Solid lines: numerically computed kappa_2(Q).
%   Dashed lines: asymptotic formula 4*n^2 / (pi^2 * (1-rho)) from equation (12).
%
%   Reference: Section 2.2, equation (12).

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

n_vals   = [100, 500, 1000];
rho_vals = linspace(0.01, 0.9999, 200);
mu       = 1;

colors   = {'#0072BD', '#D95319', '#EDB120'};
fig = figure('Name','Fig1_kappa_vs_rho','Position',[100,100,800,500]);
hold on; box on; grid on;

h_num  = gobjects(length(n_vals),1);
h_asym = gobjects(length(n_vals),1);

for ni = 1:length(n_vals)
    n      = n_vals(ni);
    kap_num  = zeros(size(rho_vals));
    kap_asym = zeros(size(rho_vals));

    for ri = 1:length(rho_vals)
        rho = rho_vals(ri);
        if rho >= 1 - 1e-6, continue; end
        lambda = rho * mu;
        [~, Qt, ~] = mmn_generator(n, lambda, mu);
        sv = svd(Qt);
        sv_pos = sv(sv > 1e-15 * max(sv));
        kap_num(ri) = max(sv_pos) / min(sv_pos);
        kap_asym(ri) = condition_number_asymptotic(n, rho);
    end

    valid = kap_num > 0;
    h_num(ni) = semilogy(rho_vals(valid), kap_num(valid), '-', ...
        'Color', colors{ni}, 'LineWidth', 1.8, ...
        'DisplayName', sprintf('n = %d, numeric', n));
    h_asym(ni) = semilogy(rho_vals(valid), kap_asym(valid), '--', ...
        'Color', colors{ni}, 'LineWidth', 1.2, ...
        'DisplayName', sprintf('n = %d, asymptotic', n));
end

xlabel('Traffic intensity \rho', 'FontSize', 12);
ylabel('\kappa_2(Q)', 'FontSize', 12);
title('Spectral condition number vs \rho (log scale)', 'FontSize', 12);
legend([h_num; h_asym], 'Location', 'northwest', 'FontSize', 9);
set(gca, 'YScale', 'log', 'FontSize', 11);
xlim([0, 1]); ylim([1e0, 1e16]);
set(gcf, 'Color', 'w');

% Annotate asymptotic formula
text(0.62, 1e13, '4n^2/(\pi^2\epsilon_\rho)', 'FontSize', 11, ...
    'Interpreter', 'tex');

saveas(fig, fullfile(fileparts(mfilename('fullpath')), 'fig1_kappa_vs_rho.pdf'));
fprintf('Figure 1 saved to fig1_kappa_vs_rho.pdf\n');
