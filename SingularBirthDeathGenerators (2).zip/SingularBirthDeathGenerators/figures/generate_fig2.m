% GENERATE_FIG2  Figure 2: PCG residual histories.
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   3x3 grid of panels: columns = n in {100,500,1000}, rows = rho in {0.99,0.999,0.9999}.
%   Each panel: Strategy A (solid), unpreconditioned CG (dashed),
%               Tikhonov-preconditioned CG (dotted).
%
%   Reference: Section 4.1.1, Figure 2.

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

n_vals   = [100, 500, 1000];
rho_vals = [0.99, 0.999, 0.9999];
mu       = 1;
maxit    = 20;
tol_pcg  = 1e-12;

fig = figure('Name','Fig2_PCG_residuals','Position',[50,50,1100,700]);
tiledlayout(3, 3, 'TileSpacing','compact','Padding','compact');

for ri = 1:length(rho_vals)
    rho    = rho_vals(ri);
    lambda = rho * mu;

    for ni = 1:length(n_vals)
        n = n_vals(ni);
        ax = nexttile;

        [Q, ~, pi_ex] = mmn_generator(n, lambda, mu);
        [Qt, D, ~]    = symmetrise_generator(full(Q), pi_ex);
        [Abd, bbd]    = bordered_system(Qt, D);

        % Strategy A
        [R, P, ~] = build_restriction(n);
        Qc   = galerkin_coarsen(Qt, R, P);
        tau  = 0.1 * norm(Qc, 2);
        [Qc_rep, ~, ~, ~] = spectral_repair(Qc, tau);
        [~, ~, res_A] = pcg_multiscale(Abd, bbd, Qc_rep, R, P, ...
            'tol', tol_pcg, 'maxit', maxit);

        % Unpreconditioned CG (MATLAB built-in, no preconditioner)
        res_unp = zeros(maxit+1,1);
        x_cg = zeros(n,1);
        r_cg = bbd - Abd*x_cg;
        res_unp(1) = norm(r_cg)/norm(bbd);
        p_cg = r_cg; rr = r_cg'*r_cg;
        for it = 1:maxit
            Ap = Abd*p_cg;
            al = rr/(p_cg'*Ap);
            x_cg = x_cg + al*p_cg;
            r_cg = r_cg - al*Ap;
            rr_new = r_cg'*r_cg;
            res_unp(it+1) = sqrt(rr_new)/norm(bbd);
            if res_unp(it+1) < tol_pcg, res_unp = res_unp(1:it+1); break; end
            p_cg = r_cg + (rr_new/rr)*p_cg;
            rr = rr_new;
        end

        % Tikhonov-preconditioned CG
        tau_tik = 1e-4 * norm(Qt,2);
        M_tik   = Abd + tau_tik * eye(n);
        [L_tik, ~] = chol(M_tik, 'lower');
        apply_M = @(r) L_tik' \ (L_tik \ r);
        res_tik = zeros(maxit+1,1);
        x_tik = zeros(n,1);
        r_tik = bbd;
        z_tik = apply_M(r_tik);
        p_tik = z_tik; rz = r_tik'*z_tik;
        res_tik(1) = norm(r_tik)/norm(bbd);
        for it = 1:maxit
            Ap = Abd*p_tik;
            al = rz/(p_tik'*Ap);
            x_tik = x_tik + al*p_tik;
            r_tik = r_tik - al*Ap;
            res_tik(it+1) = norm(r_tik)/norm(bbd);
            if res_tik(it+1) < tol_pcg, res_tik = res_tik(1:it+1); break; end
            z_new = apply_M(r_tik);
            rz_new = r_tik'*z_new;
            p_tik = z_new + (rz_new/rz)*p_tik;
            rz = rz_new;
        end

        % Plot
        iter_range = 0:maxit;
        semilogy(ax, 0:length(res_A)-1,   res_A,   'b-',  'LineWidth',1.5); hold(ax,'on');
        semilogy(ax, 0:length(res_unp)-1, res_unp, 'r--', 'LineWidth',1.2);
        semilogy(ax, 0:length(res_tik)-1, res_tik, 'k:',  'LineWidth',1.2);
        yline(ax, tol_pcg, '-.', '\epsilon_{rel}=10^{-12}', 'Color',[.5,.5,.5],'LineWidth',0.8);
        xlim(ax, [0, maxit]); ylim(ax, [1e-16, 1e1]);
        grid(ax, 'on'); box(ax, 'on');

        if ni == 1
            ylabel(ax, sprintf('\\rho=%.4f\n||r_k||/||b||', rho), 'FontSize', 8);
        end
        if ri == 1
            title(ax, sprintf('n = %d', n), 'FontSize', 9);
        end
        if ri == 3
            xlabel(ax, 'Iteration k', 'FontSize', 8);
        end
    end
end

% Legend
Lax = nexttile(1);
legend(Lax, {'Strategy A (proposed)','Unpreconditioned CG','Tikhonov-prec. CG','\epsilon_{rel}=10^{-12}'}, ...
    'Location','southwest','FontSize',8);

sgtitle('PCG residual histories ||r_k||/||b|| vs iteration', 'FontSize',11);
set(gcf,'Color','w');
saveas(fig, fullfile(fileparts(mfilename('fullpath')),'fig2_pcg_residuals.pdf'));
fprintf('Figure 2 saved to fig2_pcg_residuals.pdf\n');
