% PAULSSON_MODEL  Gene-expression noise model (Section 4.1.2).
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Paulsson model on {0,...,Nmax} with state-dependent rates:
%     lambda_i = kr * (Nmax - i) / Nmax
%     mu_i     = gamma * i
%
%   Reference stationary distribution: binomial(Nmax, p) with p = kr/(kr+gamma*Nmax).
%   Reproduces Table 10.

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

configs = {
    5,    0.02, 500;
    10,   0.02, 500;
    5,    0.01, 500;
    5,    0.02, 200;
    5,    0.02, 1000;
};

fprintf('%-4s  %-5s  %-6s  %-12s  %-22s  %-10s  %-6s  %-10s  %-12s\n', ...
    'kr','gamma','Nmax','kappa_2(Q)','sigma_max(Qc)/||Qt||_2','kappa_2(Q_c_rep)','PCG','Th.bnd','l1_error');
fprintf('%s\n', repmat('-',1,105));

for cfg = 1:size(configs,1)
    kr   = configs{cfg,1};
    gam  = configs{cfg,2};
    Nmax = configs{cfg,3};
    N    = Nmax + 1;

    % Build generator
    i_vec  = (0:Nmax-1)';
    lam_i  = kr * (Nmax - i_vec) / Nmax;   % lambda_0,...,lambda_{Nmax-1}
    mu_i   = gam * (1:Nmax)';               % mu_1,...,mu_Nmax

    main_d = zeros(N,1);
    main_d(1)       = -lam_i(1);
    main_d(2:Nmax)  = -(lam_i(2:end) + mu_i(1:end-1));
    main_d(N)       = -mu_i(end);

    Q = spdiags([mu_i; 0], -1, N, N) + spdiags(main_d, 0, N, N) + ...
        spdiags([0; lam_i], 1, N, N);

    % Exact binomial reference
    p_binom  = kr / (kr + gam * Nmax);
    pi_exact = binopdf((0:Nmax)', Nmax, p_binom);

    % Condition number
    Qt_dense = full(spdiags([mu_i;0].*sqrt((0:Nmax-1)'.*(1:Nmax)'), ...
        -1, N, N));  % approximate; use symmetrise for accuracy
    [Qt, D, ~] = symmetrise_generator(full(Q), pi_exact);
    kappa_Q = cond(Qt);

    % Framework
    [R, P, nc] = build_restriction(N);
    Qc = galerkin_coarsen(Qt, R, P);
    tau = 0.1 * norm(Qc, 2);
    [Qc_rep, ~, ~, kappa_rep] = spectral_repair(Qc, tau);
    ratio = norm(Qc,2) / norm(Qt,2);

    [pi_prop, info] = stationary_framework(full(Q), 'pi_star', pi_exact, ...
        'strategy', 'A', 'tol', 1e-12, 'verbose', false);
    l1_err = norm(pi_prop - pi_exact, 1);

    % Theorem 3.6 theoretical bound (conservative; C absorbs factor 40)
    lam_bar = mean(lam_i);
    delta_rate = max(abs(lam_i - lam_bar)) / lam_bar;
    C_const = 40 * (max(lam_i)/min(lam_i));   % conservative C
    th_bound = ceil(9 + C_const * delta_rate);

    fprintf('%-4d  %-5.2f  %-6d  %-12.2e  %-22.2f  %-16.1f  %-6d  %-10d  %-12.2e\n', ...
        kr, gam, Nmax, kappa_Q, ratio, kappa_rep, info.iter, th_bound, l1_err);
end
