% THRESHOLD_SENSITIVITY  Sensitivity to regularisation threshold tau (Section 4.6).
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Reproduces Tables 19 and 22.

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

%% Table 19: Synthetic benchmark
fprintf('=== Table 19: Threshold sensitivity, n=100, delta_diag=1e-10 ===\n\n');
fprintf('%-18s  %-14s  %-16s  %-20s\n', ...
    'tau / sigma_max','kappa_2(Q_c_rep)','Solution error','||Qc-Q_c_rep||/||Qc||');
fprintf('%s\n', repmat('-',1,75));

n = 100; d_diag = 1e-10;
A = full(spdiags(ones(n,1)*[1, d_diag, 1], [-1,0,1], n, n));
b_rhs = randn(n,1); rng(0);

[R, P, ~] = build_restriction(n);
Qc = galerkin_coarsen(A, R, P);
sig_max = norm(Qc, 2);
x_ref = A \ b_rhs;

tau_fracs = [1e-2, 1e-1, 0.5, 1.0];
for tf = tau_fracs
    tau = tf * sig_max;
    [Qc_rep, ~, ~, kappa_rep] = spectral_repair(Qc, tau);
    [x_A, ~, ~] = pcg_multiscale(A, b_rhs, Qc_rep, R, P, 'tol',1e-12,'maxit',200);
    sol_err = norm(x_A - x_ref) / norm(x_ref);
    pert_ratio = norm(Qc - Qc_rep, 2) / norm(Qc, 2);
    fprintf('%-18s  %-14.0f  %-16.2e  %-20.2e\n', ...
        sprintf('%.0e sigma_max', tf), kappa_rep, sol_err, pert_ratio);
end
