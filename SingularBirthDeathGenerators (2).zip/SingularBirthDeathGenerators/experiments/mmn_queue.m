% MMN_QUEUE  Reproduce Tables 8 and 9.
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Stationary distribution accuracy for the M/M/1/n queue at
%   moderate load (rho=0.99) and near-critical load (rho in {0.999, 0.9999}).
%
%   Methods compared:
%     1. Detailed-balance recurrence (equation 7)
%     2. LU with partial pivoting
%     3. Tikhonov regularisation (tau = 1e-4 * ||Qt||_2)
%     4. Proposed framework, Strategy A
%
%   Reference: Section 4.1.1.

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

mu     = 1;
rho_moderate  = 0.99;
rho_critical  = [0.999, 0.9999];
n_vals = [100, 500, 1000];

fprintf('=== Table 8: Moderate load rho = %.2f ===\n\n', rho_moderate);
fprintf('%-30s  %12s  %12s  %12s\n', 'Method', 'n=100', 'n=500', 'n=1000');
fprintf('%s\n', repmat('-', 1, 72));

methods_mod = {'Recurrence', 'LU', 'Proposed (Strat. A)'};
err_mod = zeros(3, 3);

for ni = 1:length(n_vals)
    n      = n_vals(ni);
    lambda = rho_moderate * mu;
    [Q, Qt_mm, pi_exact] = mmn_generator(n, lambda, mu);
    [Qt, D, ~]            = symmetrise_generator(Q, pi_exact);
    [Abd, bbd]            = bordered_system(Qt, D);

    % 1. Recurrence
    [pi_rec, flag_rec] = recurrence_solve(Q);
    if flag_rec == 0
        err_mod(1, ni) = norm(pi_rec - pi_exact, 1);
    else
        err_mod(1, ni) = NaN;
    end

    % 2. LU
    try
        pi_lu = lu_solve_bordered(Abd, bbd, Qt, D);
        err_mod(2, ni) = norm(pi_lu - pi_exact, 1);
    catch
        err_mod(2, ni) = NaN;
    end

    % 3. Proposed Strategy A
    [pi_prop, info] = stationary_framework(Q, 'pi_star', pi_exact, ...
        'strategy', 'A', 'tol', 1e-12, 'verbose', false);
    err_mod(3, ni) = norm(pi_prop - pi_exact, 1);
end

for m = 1:3
    row = sprintf('%.2e  %.2e  %.2e', err_mod(m,1), err_mod(m,2), err_mod(m,3));
    fprintf('%-30s  %s\n', methods_mod{m}, row);
end

fprintf('\n=== Table 9: Near-critical load ===\n\n');
fprintf('%-26s  %12s  %12s  %12s  %12s  %12s  %12s\n', 'Method', ...
    'n=100/0.999','n=100/0.9999','n=500/0.999','n=500/0.9999','n=1k/0.999','n=1k/0.9999');
fprintf('%s\n', repmat('-', 1, 105));

methods_crit = {'Recurrence','LU','Tikhonov(1e-4)','Proposed(A)'};
err_crit = zeros(4, length(n_vals), length(rho_critical));

for ri = 1:length(rho_critical)
    rho = rho_critical(ri);
    for ni = 1:length(n_vals)
        n      = n_vals(ni);
        lambda = rho * mu;
        [Q, ~, pi_exact] = mmn_generator(n, lambda, mu);
        [Qt, D, ~]        = symmetrise_generator(Q, pi_exact);
        [Abd, bbd]        = bordered_system(Qt, D);

        % Recurrence
        [pi_rec, flag_rec] = recurrence_solve(Q);
        err_crit(1, ni, ri) = flag_rec*NaN + (1-abs(flag_rec))*norm(pi_rec-pi_exact,1);
        if flag_rec ~= 0, err_crit(1,ni,ri) = NaN; end

        % LU
        try
            pi_lu = lu_solve_bordered(Abd, bbd, Qt, D);
            if any(pi_lu < -1e-10) || norm(pi_lu,1) < 0.5
                err_crit(2,ni,ri) = NaN;
            else
                err_crit(2,ni,ri) = norm(pi_lu - pi_exact, 1);
            end
        catch
            err_crit(2,ni,ri) = NaN;
        end

        % Tikhonov
        try
            [pi_tik, ~] = tikhonov_solve(Qt, D, 1e-4);
            err_crit(3,ni,ri) = norm(pi_tik - pi_exact, 1);
        catch
            err_crit(3,ni,ri) = NaN;
        end

        % Proposed Strategy A
        [pi_prop, ~] = stationary_framework(Q, 'pi_star', pi_exact, ...
            'strategy', 'A', 'tol', 1e-12);
        err_crit(4,ni,ri) = norm(pi_prop - pi_exact, 1);
    end
end

for m = 1:4
    row = '';
    for ni = 1:3
        for ri = 1:2
            v = err_crit(m,ni,ri);
            if isnan(v)
                row = [row, sprintf('  %12s', '---')];
            else
                row = [row, sprintf('  %12.2e', v)];
            end
        end
    end
    fprintf('%-26s%s\n', methods_crit{m}, row);
end

%% Helper: LU solve on bordered system
function pi_out = lu_solve_bordered(Abd, bbd, Qt, D)
    warning('off', 'MATLAB:singularMatrix');
    warning('off', 'MATLAB:nearlySingularMatrix');
    pi_tilde = Abd \ bbd;
    warning('on', 'MATLAB:singularMatrix');
    warning('on', 'MATLAB:nearlySingularMatrix');
    d = diag(D);
    pi_out = pi_tilde ./ d;
    pi_out = abs(pi_out) / sum(abs(pi_out));
end
