% SYNTHETIC_BENCHMARK  Parametric family A_{delta_diag} (Section 4.2, equation 13).
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   A_delta_diag = tridiag(1, delta_diag, 1) in R^{n x n}
%   Eigenvalues: lambda_j = delta_diag + 2*cos(j*pi/(n+1)), j=1,...,n
%   kappa_2(A) ~ (4 + delta_diag) / delta_diag
%
%   Reproduces Tables 15, 16, 17.

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

n_vals     = [100, 1000, 5000];
delta_vals = [1e-4, 1e-6, 1e-8, 1e-12];
n_rhs      = 100;   % right-hand sides per configuration
n_seeds    = 5;
rng(42);

%% Table 15: Success rates across methods
fprintf('=== Table 15: Success rates (threshold 1e-1) ===\n\n');
fprintf('%-32s  %8s  %8s  %8s  %8s  %8s\n','Method','Iter std','Err std','n=100','n=1000','n=5000');
fprintf('%s\n', repmat('-',1,80));

% (Full Table 15 requires multiple competitive methods. Here we demonstrate
%  the proposed method and LU; other baselines follow the same pattern.)

for ni = 1:length(n_vals)
    n = n_vals(ni);
    d_test = 1e-10;

    % Build A
    A = spdiags(ones(n,1)*[1, d_test, 1], [-1,0,1], n, n);
    A = full(A);

    success_A = 0;
    success_lu = 0;
    iter_list = zeros(n_rhs, 1);
    err_list  = zeros(n_rhs, 1);

    for r = 1:n_rhs
        b_rhs = randn(n, 1);
        x_true = A \ b_rhs;   % reference solution

        % Proposed Strategy A (treat A as symmetric near-tridiagonal)
        [R, P, nc] = build_restriction(n);
        Qc = galerkin_coarsen(A, R, P);
        tau = 0.1 * norm(Qc, 2);
        [Qc_rep, ~, ~, ~] = spectral_repair(Qc, tau);
        try
            [x_A, iter_r, res_h] = pcg_multiscale(A, b_rhs, Qc_rep, R, P, ...
                'tol', 1e-12, 'maxit', 50);
            rel_err = norm(x_A - x_true) / norm(x_true);
            if rel_err < 0.1, success_A = success_A + 1; end
            iter_list(r) = iter_r;
            err_list(r)  = rel_err;
        catch
        end

        % LU baseline
        try
            x_lu = A \ b_rhs;
            if norm(x_lu - x_true)/norm(x_true) < 0.1, success_lu = success_lu + 1; end
        catch
        end
    end
    fprintf('n=%d: Proposed A success=%.1f%%  LU success=%.1f%%  iter_mean=%.1f\n', ...
        n, 100*success_A/n_rhs, 100*success_lu/n_rhs, mean(iter_list));
end

%% Table 17: Scaling study
fprintf('\n=== Table 17: Scaling study (Strategy A) ===\n\n');
fprintf('%-6s  %-5s  %-6s  %-6s  %-6s  %-6s  %-12s  %-10s  %-8s  %-8s\n', ...
    'n','nc','d=1e-4','d=1e-6','d=1e-8','d=1e-12','kappa_2(A)','kappa_Qc_rep','Setup(s)','Solve(s)');
fprintf('%s\n', repmat('-',1,100));

for n = [100, 500, 1000, 5000]
    nc = floor(n/2);
    [R, P, nc_r] = build_restriction(n);

    iter_row = zeros(1, length(delta_vals));
    for di = 1:length(delta_vals)
        d_diag = delta_vals(di);
        A = spdiags(ones(n,1)*[1, d_diag, 1], [-1,0,1], n, n);
        A = full(A);
        b_rhs = randn(n,1);

        t_s = tic;
        Qc = galerkin_coarsen(A, R, P);
        tau = 0.1 * norm(Qc,2);
        [Qc_rep, ~, ~, kappa_rep] = spectral_repair(Qc, tau);
        t_setup = toc(t_s);

        t_sv = tic;
        [~, iter_r, ~] = pcg_multiscale(A, b_rhs, Qc_rep, R, P, 'tol',1e-12,'maxit',50);
        t_solve = toc(t_sv);

        iter_row(di) = iter_r;
    end
    kappa_A = (4 + delta_vals(3)) / delta_vals(3);  % at d=1e-8
    fprintf('%-6d  %-5d  %-6d  %-6d  %-6d  %-6d  %-12.2e  %-10.1f  %-8.4f  %-8.4f\n', ...
        n, nc_r, iter_row(1), iter_row(2), iter_row(3), iter_row(4), ...
        kappa_A, kappa_rep, t_setup, t_solve);
end
