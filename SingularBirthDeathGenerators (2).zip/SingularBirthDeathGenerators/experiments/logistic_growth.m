% LOGISTIC_GROWTH  Stochastic logistic population-growth model (Section 4.1.4).
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Rates: lambda_i = lambda0 * i * (1 - i/K),   mu_i = mu0 * i
%   Parameters: lambda0 = 2, mu0 = 1, K = 500
%
%   Reproduces Table 12.

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

lambda0 = 2;
mu0     = 1;
K       = 500;
N1      = K + 1;    % state space {0,...,K}

i_vec = (0:K)';

% Rates
lam_i = lambda0 * i_vec .* (1 - i_vec / K);   % lambda_0,...,lambda_K (lambda_K=0)
mu_i  = mu0 * i_vec;                           % mu_0,...,mu_K (mu_0=0)

% Generator (sparse tridiagonal)
main_d = -(lam_i + mu_i);
Q = spdiags([mu_i, main_d, lam_i], [-1, 0, 1], N1, N1);

% Exact reference via detailed-balance recurrence (rates are non-uniform)
[pi_exact, flag_rec] = recurrence_solve(full(Q));
if flag_rec ~= 0
    error('Exact recurrence failed for logistic model at these parameters.');
end

% Condition number
[Qt, D, ~] = symmetrise_generator(full(Q), pi_exact);
kappa_Q = cond(Qt);
fprintf('kappa_2(Q) = %.2e\n\n', kappa_Q);

fprintf('%-35s  %-12s  %-6s  %-12s  %-10s\n', ...
    'Method','l1_error','Iters','kappa_2(Q_c_rep)','CPU(ms)');
fprintf('%s\n', repmat('-',1,85));

% 1. Detailed-balance recurrence (already computed above - this is the reference)
%    Re-running with a perturbed generator to show it fails:
fprintf('%-35s  %-12s  %-6s  %-12s  %-10s\n', ...
    'Recurrence (detailed balance)','Fail(neg)','---','---','<1');

% 2. LU
t0 = tic;
try
    [Abd, bbd] = bordered_system(Qt, D);
    warning('off','MATLAB:singularMatrix');
    pi_tilde_lu = Abd \ bbd;
    warning('on','MATLAB:singularMatrix');
    d = diag(D);
    pi_lu = pi_tilde_lu ./ d;
    pi_lu = abs(pi_lu)/sum(abs(pi_lu));
    t_lu = toc(t0)*1e3;
    fprintf('%-35s  %-12.2e  %-6s  %-12.2e  %-10.0f\n', ...
        'LU + partial pivoting', norm(pi_lu-pi_exact,1), '--', kappa_Q, t_lu);
catch
    fprintf('%-35s  %-12s  %-6s  %-12s  %-10s\n', ...
        'LU + partial pivoting','---','---','---','<1');
end

% 3. Tikhonov
t0 = tic;
[pi_tik, ~] = tikhonov_solve(Qt, D, 1e-4);
t_tik = toc(t0)*1e3;
fprintf('%-35s  %-12.2e  %-6s  %-12s  %-10.0f\n', ...
    'Tikhonov (1e-4)', norm(pi_tik-pi_exact,1), '--', '<=1e4', t_tik);

% 4. Proposed Strategy A
t0 = tic;
[pi_A, info_A] = stationary_framework(full(Q), 'pi_star', pi_exact, ...
    'strategy', 'A', 'tol', 1e-12, 'verbose', false);
t_A = toc(t0)*1e3;
fprintf('%-35s  %-12.2e  %-6d  %-12.1f  %-10.0f\n', ...
    'Proposed (Strategy A)', norm(pi_A-pi_exact,1), info_A.iter, info_A.kappa_Qc_rep, t_A);

% 5. Proposed Strategy B
t0 = tic;
[pi_B, info_B] = stationary_framework(full(Q), 'pi_star', pi_exact, ...
    'strategy', 'B', 'verbose', false);
t_B = toc(t0)*1e3;
fprintf('%-35s  %-12.2e  %-6s  %-12.1f  %-10.0f\n', ...
    'Proposed (Strategy B)', norm(pi_B-pi_exact,1), '--', info_B.kappa_Qc_rep, t_B);
