% LACZ_VALIDATION  E. coli lacZ mRNA validation (Section 4.1.3).
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Parameters from Golding et al. (2005), Table 1:
%     kappa  = 0.0167 min^{-1}  (transcription initiation rate)
%     gamma_m = 0.139  min^{-1}  (mRNA degradation rate)
%     b       = 4.0              (mean burst size)
%
%   Stationary distribution reference: negative binomial (equation 40).
%   Reproduces Table 11.

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

%% Model parameters (Golding et al. 2005, Table 1)
kappa_rate = 0.0167;   % transcription initiation rate (min^{-1})
gamma_m    = 0.139;    % mRNA degradation rate (min^{-1})
b_burst    = 4.0;      % mean burst size

rho_model  = kappa_rate * b_burst / gamma_m;
fprintf('Model parameters: kappa=%.4f, gamma_m=%.3f, b=%.1f\n', ...
    kappa_rate, gamma_m, b_burst);
fprintf('rho = kappa*b/gamma_m = %.4f\n\n', rho_model);

%% State space: Poisson-burst model on {0,...,n}
n_states = 40;   % captures >99.9% of stationary mass

% Poisson-burst rates (effective birth-death form):
% lambda_i = kappa_rate * b_burst  (production by bursting)
% mu_i     = gamma_m * i           (degradation)
lam_const = kappa_rate * b_burst;
mu_vec    = gamma_m * (1:n_states)';
lam_vec   = lam_const * ones(n_states, 1);

N1     = n_states + 1;
main_d = zeros(N1, 1);
main_d(1)           = -lam_const;
main_d(2:n_states)  = -(lam_const + gamma_m*(1:n_states-1)');
main_d(N1)          = -gamma_m * n_states;

Q = spdiags([mu_vec; 0], -1, N1, N1) + spdiags(main_d, 0, N1, N1) + ...
    spdiags([0; lam_vec], 1, N1, N1);

%% Analytical negative-binomial reference (equation 40)
r_nb = kappa_rate / gamma_m;    % r = kappa/gamma_m approx 0.1201
p_nb = b_burst / (1 + b_burst); % p = b/(1+b) = 0.8
k_vec = (0:n_states)';
pi_negbinom = nbinpdf(k_vec, r_nb, 1 - p_nb);
pi_negbinom = pi_negbinom / sum(pi_negbinom);

%% Observed histogram (digitised from Golding et al. Fig. 1C)
obs_hist = [0.22; 0.18; 0.14; 0.11; 0.09; 0.07];
obs_mass_rest = 1 - sum(obs_hist);
n_obs = length(obs_hist);
obs_full = [obs_hist; obs_mass_rest / (n_states + 1 - n_obs) * ones(n_states + 1 - n_obs, 1)];
obs_full = obs_full / sum(obs_full);

fprintf('Analytical NB vs observed histogram: l1 = %.3f\n\n', ...
    norm(pi_negbinom - obs_full, 1));

%% Run methods
[Qt, D, ~] = symmetrise_generator(full(Q), pi_negbinom);
kappa_Q = cond(Qt);
fprintf('kappa_2(Q) = %.2e\n\n', kappa_Q);

fprintf('%-35s  %-14s  %-14s  %-8s  %-6s\n', ...
    'Method', 'l1 vs anal.', 'l1 vs obs.', 'Iters', 'Fails?');
fprintf('%s\n', repmat('-',1,82));

% 1. Proposed Strategy A
[pi_prop, info] = stationary_framework(full(Q), 'pi_star', pi_negbinom, ...
    'strategy', 'A', 'tol', 1e-12);
err_anal  = norm(pi_prop - pi_negbinom, 1);
err_obs   = norm(pi_prop - obs_full, 1);
fprintf('%-35s  %-14.2e  %-14.3f  %-8d  No\n', ...
    'Proposed (Strategy A)', err_anal, err_obs, info.iter);

% 2. Tikhonov
[pi_tik, ~] = tikhonov_solve(Qt, D, 1e-4);
err_tik = norm(pi_tik - pi_negbinom, 1);
err_tik_obs = norm(pi_tik - obs_full, 1);
fprintf('%-35s  %-14.2e  %-14.3f  %-8s  No\n', ...
    'Tikhonov (1e-4 ||Qt||_2)', err_tik, err_tik_obs, '--');

% 3. LU
try
    [Abd, bbd] = bordered_system(Qt, D);
    warning('off','MATLAB:singularMatrix');
    pi_tilde_lu = Abd \ bbd;
    warning('on','MATLAB:singularMatrix');
    d = diag(D);
    pi_lu = pi_tilde_lu ./ d;
    if any(pi_lu < -1e-8) || ~isfinite(sum(pi_lu))
        fprintf('%-35s  %-14s  %-14s  %-8s  Yes (indef. pivot)\n', ...
            'LU + partial pivoting','---','---','---');
    else
        pi_lu = abs(pi_lu)/sum(abs(pi_lu));
        fprintf('%-35s  %-14.2e  %-14.3f  %-8s  No\n', ...
            'LU + partial pivoting', norm(pi_lu-pi_negbinom,1), ...
            norm(pi_lu-obs_full,1), '--');
    end
catch
    fprintf('%-35s  %-14s  %-14s  %-8s  Yes\n','LU + partial pivoting','---','---','---');
end

% 4. Recurrence
[pi_rec, flag_rec] = recurrence_solve(full(Q));
if flag_rec == 0
    fprintf('%-35s  %-14.2e  %-14.3f  %-8s  No\n', ...
        'Detailed-balance recurrence', norm(pi_rec-pi_negbinom,1), ...
        norm(pi_rec-obs_full,1), '--');
else
    fprintf('%-35s  %-14s  %-14s  %-8s  Yes (neg. probs.)\n', ...
        'Detailed-balance recurrence','---','---','---');
end

fprintf('\nNegative-binomial reference:     l1 vs obs = %.3f\n', ...
    norm(pi_negbinom - obs_full, 1));
