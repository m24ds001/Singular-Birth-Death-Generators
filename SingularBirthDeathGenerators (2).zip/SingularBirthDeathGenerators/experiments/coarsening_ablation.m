% COARSENING_ABLATION  Coarsening ratio ablation (Section 4.5).
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Compares 2:1, 3:1, 4:1 coarsening on the synthetic benchmark family
%   at n=1000 and delta_diag in {1e-8, 1e-12}.
%   Reproduces Table 18.

clear; clc;
addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..')));

n = 1000;
delta_vals = [1e-8, 1e-12];
ratios     = [2, 3, 4];
rng(42);

fprintf('=== Table 18: Coarsening ratio ablation, n=%d ===\n\n', n);
fprintf('%-6s  %-5s  %-14s  %-14s  %-14s  %-14s  %-12s  %-12s\n', ...
    'Ratio','nc','kappa_2(Q_c_rep)','PCG(d=1e-8)','PCG(d=1e-12)','Stage2(ms)','TotalCPU(ms)','SolErr');
fprintf('%s\n', repmat('-',1,100));

b_rhs = randn(n,1);

for c = ratios
    nc = floor(n / c);

    % Build c:1 restriction: R_{k,i} = 1/c if i in {(k-1)*c+1,...,k*c}
    rows_r = []; cols_r = []; vals_r = [];
    for k = 1:nc
        for j = 1:c
            idx = (k-1)*c + j;
            if idx <= n
                rows_r = [rows_r; k];
                cols_r = [cols_r; idx];
                vals_r = [vals_r; 1/c];
            end
        end
    end
    R_c = sparse(rows_r, cols_r, vals_r, nc, n);
    P_c = R_c';

    iter_list = zeros(length(delta_vals), 1);
    t_s2_list = zeros(length(delta_vals), 1);
    t_tot_list= zeros(length(delta_vals), 1);
    kappa_rep_list = zeros(length(delta_vals), 1);
    err_list  = zeros(length(delta_vals), 1);

    for di = 1:length(delta_vals)
        d_diag = delta_vals(di);
        A = full(spdiags(ones(n,1)*[1, d_diag, 1], [-1,0,1], n, n));
        x_ref = A \ b_rhs;

        t_total = tic;
        t_s2 = tic;
        Qc = R_c * A * P_c;
        Qc = 0.5*(Qc + Qc');
        tau = 0.1 * norm(Qc, 2);
        [Qc_rep, ~, ~, kappa_rep] = spectral_repair(Qc, tau);
        t_s2_val = toc(t_s2)*1e3;

        [x_A, iter_r, ~] = pcg_multiscale(A, b_rhs, Qc_rep, R_c, P_c, ...
            'tol', 1e-12, 'maxit', 100);
        t_tot_val = toc(t_total)*1e3;

        iter_list(di)      = iter_r;
        t_s2_list(di)      = t_s2_val;
        t_tot_list(di)     = t_tot_val;
        kappa_rep_list(di) = kappa_rep;
        err_list(di)       = norm(x_A - x_ref)/norm(x_ref);
    end

    fprintf('%-6d  %-5d  %-14.1f  %-14d  %-14d  %-14.0f  %-12.0f  %-12.2e\n', ...
        c, nc, kappa_rep_list(1), iter_list(1), iter_list(2), ...
        t_s2_list(1), t_tot_list(1), err_list(1));
end
