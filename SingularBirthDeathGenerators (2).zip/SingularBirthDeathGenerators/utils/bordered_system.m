function [Abd, bbd] = bordered_system(Qt, D)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% BORDERED_SYSTEM  Assemble the bordered SPD system (equation 5).
%
%   Replaces row 0 of Qt' by the normalisation constraint (D^{-1/2} * 1)':
%
%     A_tilde_bd * pi_tilde = b_tilde_bd
%
%   where row 0 encodes 1' D^{-1} pi_tilde = 1 (i.e., sum(pi*) = 1 after
%   back-transformation).  This removes the singularity and introduces a
%   strictly positive pivot, making A_tilde_bd symmetric positive definite.
%
% Input:
%   Qt  - n x n symmetrised generator (symmetric tridiagonal)
%   D   - n x n diagonal matrix diag(sqrt(pi*))
%
% Output:
%   Abd  - n x n SPD bordered coefficient matrix
%   bbd  - n x 1 right-hand side (zero except first entry = 1)
%
% Reference: Section 1.1, equation (5).

n  = size(Qt, 1);
d  = diag(D);           % sqrt(pi_i^*)

% Normalisation row: (D^{-1/2} * 1)' = 1 ./ sqrt(pi*) row
norm_row = (1 ./ d)';   % 1 x n

% Bordered system: replace first row of Qt^T by normalisation constraint
Abd      = Qt';
Abd(1,:) = norm_row;

% Right-hand side: zero everywhere, 1 in the first entry
bbd      = zeros(n, 1);
bbd(1)   = 1;

end
