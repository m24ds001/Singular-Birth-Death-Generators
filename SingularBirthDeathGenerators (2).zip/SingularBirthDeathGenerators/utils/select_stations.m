function station_ids = select_stations(lat_range, lon_range, n_stations)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% SELECT_STATIONS  Select NOAA GHCN-Daily stations for ridge regression experiment.
%
%   Filters stations by geographic bounding box, sorts by latitude, and
%   returns the first n_stations identifiers.  This utility reproduces the
%   station-selection step described in Section 5.1.
%
%   Data source: NOAA GHCN-Daily
%   https://www.ncei.noaa.gov/products/land-based-station/global-historical-climatology-network-daily
%
% Usage:
%   station_ids = select_stations([25, 50], [-130, -60], 500)
%
% Input:
%   lat_range    - [lat_min, lat_max] in degrees
%   lon_range    - [lon_min, lon_max] in degrees
%   n_stations   - number of stations to return
%
% Output:
%   station_ids  - cell array of station identifier strings (sorted by latitude)
%
% Note: Requires the GHCN-Daily station inventory file 'ghcnd-stations.txt'
%       available from the NOAA FTP server. Place the file in the same
%       directory as this function or supply the full path via the
%       environment variable GHCND_STATIONS_PATH.

% Locate station inventory file
env_path = getenv('GHCND_STATIONS_PATH');
if ~isempty(env_path) && isfile(env_path)
    inv_file = env_path;
else
    candidates = {
        fullfile(fileparts(mfilename('fullpath')), 'ghcnd-stations.txt');
        fullfile(pwd, 'ghcnd-stations.txt');
    };
    inv_file = '';
    for c = 1:length(candidates)
        if isfile(candidates{c})
            inv_file = candidates{c};
            break;
        end
    end
end

if isempty(inv_file)
    error(['select_stations: ghcnd-stations.txt not found. ', ...
        'Download from https://www1.ncdc.noaa.gov/pub/data/ghcn/daily/ ', ...
        'and set GHCND_STATIONS_PATH or place file in utils/.']);
end

% Parse fixed-width GHCN-Daily inventory (columns as per NOAA format)
fid = fopen(inv_file, 'r');
raw = textscan(fid, '%11s %8.4f %9.4f %6.1f %s', 'Delimiter', '\n', ...
    'WhiteSpace', '');
fclose(fid);

ids  = raw{1};
lats = raw{2};
lons = raw{3};

% Filter by bounding box
in_lat = (lats >= lat_range(1)) & (lats <= lat_range(2));
in_lon = (lons >= lon_range(1)) & (lons <= lon_range(2));
mask   = in_lat & in_lon;

ids_sel  = ids(mask);
lats_sel = lats(mask);

if length(ids_sel) < n_stations
    warning('select_stations: only %d stations found; requested %d.', ...
        length(ids_sel), n_stations);
    n_stations = length(ids_sel);
end

% Sort by latitude (ascending) to produce spatially ordered design matrix
[~, ord] = sort(lats_sel);
station_ids = ids_sel(ord(1:n_stations));

end
