function [pi_star, flag] = recurrence_solve(Q)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% RECURRENCE_SOLVE  Detailed-balance recurrence (equation 7).
%
%   pi*_i = (lambda_{i-1}/mu_i) * pi*_{i-1},  i = 1,...,n
%
%   This is the classical O(n) method; it fails (flag=-1) when rounding
%   errors in accumulated products produce negative probabilities.
%
% Output:
%   pi_star - stationary distribution (or NaN vector on failure)
%   flag    -  0: success
%             -1: negative probability encountered (failure)
%             -2: numerical overflow (failure)

n1 = size(Q, 1);
n  = n1 - 1;

lambda = diag(Q,  1);   % super-diagonal: lambda_0,...,lambda_{n-1}
mu     = diag(Q, -1);   % sub-diagonal:   mu_1,...,mu_n

pi_star = zeros(n1, 1);
pi_star(1) = 1;
flag = 0;

for i = 1:n
    pi_star(i+1) = (lambda(i) / mu(i)) * pi_star(i);
    if pi_star(i+1) < 0
        flag = -1;
        pi_star = NaN(n1, 1);
        return;
    end
    if ~isfinite(pi_star(i+1))
        flag = -2;
        pi_star = NaN(n1, 1);
        return;
    end
end

S = sum(pi_star);
if S <= 0 || ~isfinite(S)
    flag = -2;
    pi_star = NaN(n1, 1);
    return;
end

pi_star = pi_star / S;

end
