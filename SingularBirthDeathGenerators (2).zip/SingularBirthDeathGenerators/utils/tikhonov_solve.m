function [pi_star, kappa_tik] = tikhonov_solve(Qt, D, tau_frac)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% TIKHONOV_SOLVE  Tikhonov regularised solve for the stationary distribution.
%
%   Solves (Qt + tau*I)' pi_tilde = 0 with normalisation, then recovers
%   pi* via back-transformation.  The zero-row-sum property is destroyed
%   and the stationary-distribution bias grows as ||pi_tau - pi*||_1 = O(tau*sqrt(n)/gamma)
%   (Proposition 2.1).
%
% Input:
%   Qt       - n x n symmetrised generator
%   D        - n x n diagonal matrix diag(sqrt(pi*))
%   tau_frac - tau = tau_frac * ||Qt||_2  (e.g., 1e-4)
%
% Output:
%   pi_star   - recovered stationary distribution
%   kappa_tik - kappa_2(Qt + tau*I)

tau = tau_frac * norm(Qt, 2);
n   = size(Qt, 1);

Qt_tik = Qt + tau * eye(n);
kappa_tik = cond(Qt_tik);

% Solve the regularised null-space problem via bordered system
[Abd_tik, bbd] = bordered_system(Qt_tik, D);
pi_tilde = Abd_tik \ bbd;

d        = diag(D);
pi_star  = pi_tilde ./ d;
pi_star  = abs(pi_star) / sum(abs(pi_star));

end
