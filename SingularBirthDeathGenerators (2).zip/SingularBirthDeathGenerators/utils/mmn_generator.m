function [Q, Qt, pi_exact] = mmn_generator(n, lambda, mu)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% MMN_GENERATOR  Build the M/M/1/n generator matrix Q (equation 9).
%
%   Q is the (n+1)x(n+1) tridiagonal infinitesimal generator of the
%   finite-buffer M/M/1/n queue with arrival rate lambda, service rate mu,
%   and buffer capacity n.
%
%   Boundary conditions: mu_0 = 0 (no departures from empty system),
%   lambda_n = 0 (no arrivals when buffer is full), giving
%     Q_{00} = -lambda,   Q_{nn} = -mu.
%
% Usage:
%   [Q, Qt, pi_exact] = mmn_generator(n, lambda, mu)
%
% Input:
%   n      - buffer capacity (state space {0,1,...,n})
%   lambda - arrival rate  (lambda > 0)
%   mu     - service rate  (mu > 0)
%
% Output:
%   Q        - (n+1)x(n+1) generator (sparse, non-symmetric for lambda~=mu)
%   Qt       - (n+1)x(n+1) symmetrised generator Q_tilde (equation 8)
%   pi_exact - exact geometric stationary distribution (equation below (10))
%
% Reference: Section 2.1; equations (8)-(9).

rho = lambda / mu;
N   = n + 1;      % state space size {0,...,n}

% Exact geometric stationary distribution (Section 2.1)
if abs(rho - 1) < 1e-14
    pi_exact = ones(N, 1) / N;
else
    i_vec    = (0:n)';
    pi_exact = (1 - rho) * rho.^i_vec / (1 - rho^N);
end

% Build sparse tridiagonal generator (equation 9)
main_diag = zeros(N, 1);
main_diag(1)   = -lambda;
main_diag(2:n) = -(lambda + mu);
main_diag(N)   = -mu;

super_diag = lambda * ones(n, 1);   % entries Q_{i,i+1}
sub_diag   = mu    * ones(n, 1);    % entries Q_{i+1,i}

Q = spdiags([sub_diag, main_diag, super_diag], [-1, 0, 1], N, N);

% Symmetrised generator Q_tilde (equation 8):
% off-diagonal entries are sqrt(lambda*mu); diagonal unchanged
sqrt_lmu = sqrt(lambda * mu);
main_s   = main_diag;
off_s    = sqrt_lmu * ones(n, 1);

Qt = spdiags([off_s, main_s, off_s], [-1, 0, 1], N, N);
Qt = full(Qt);

% Verify zero row sums
row_sum_err = max(abs(sum(Q, 2)));
if row_sum_err > 1e-10 * (lambda + mu)
    warning('mmn_generator: row sum error = %.2e', row_sum_err);
end

end
