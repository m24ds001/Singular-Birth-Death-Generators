function kappa = condition_number_asymptotic(n, rho)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% CONDITION_NUMBER_ASYMPTOTIC  Asymptotic spectral condition number (equation 12).
%
%   kappa_2(Q) ~ 4*n^2 / (pi^2 * epsilon_rho),  epsilon_rho = 1 - rho -> 0
%
% Input:
%   n    - chain length (scalar or vector)
%   rho  - traffic intensity (scalar or vector, must match size of n)
%
% Output:
%   kappa - asymptotic estimate of kappa_2(Q)

epsilon_rho = 1 - rho;
kappa = 4 * n.^2 ./ (pi^2 * epsilon_rho);

end
