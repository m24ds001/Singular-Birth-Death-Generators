function [Qc_prime, V, lam_prime, kappa] = spectral_repair(Qc, tau)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% SPECTRAL_REPAIR  Sign-preserving eigenvalue regularisation (Algorithm 2).
%
%   For each eigenvalue lambda_i of the symmetric Qc:
%     lambda'_i = max(|lambda_i|, tau) * sign(lambda_i)
%
%   with the convention sign(0) = +1.
%
%   Guarantees (Theorem 3.2):
%     kappa_2(Qc') <= sigma_max(Qc) / tau
%
%   Optimality (Theorem 3.8):
%     ||Qc - Qc'||_2 = max_{i: |lambda_i|<tau} (tau - |lambda_i|)
%   No member of the sign-preserving class S(Qc, tau) achieves a strictly
%   smaller spectral norm of the perturbation.
%
% Usage:
%   [Qc_prime, V, lam_prime, kappa] = spectral_repair(Qc, tau)
%
% Input:
%   Qc   - nc x nc symmetric matrix (Galerkin coarse operator)
%   tau  - regularisation threshold tau > 0
%          Recommended: tau = 0.1 * sigma_max(Qc)  [equation 25, alpha_a=0.1]
%
% Output:
%   Qc_prime  - Regularised operator Q'_c = V * diag(lam_prime) * V'
%   V         - Orthonormal eigenvector matrix (LAPACK DSYEV order)
%   lam_prime - Repaired eigenvalues (column vector)
%   kappa     - kappa_2(Qc') = max(|lam_prime|) / min(|lam_prime|)
%
% Reference: Section 2.8, equation (22); Algorithm 2 (Section 3.3).

if tau <= 0
    error('spectral_repair: threshold tau must be strictly positive.');
end

% Dense symmetric eigendecomposition (LAPACK DSYEV via MATLAB eig)
[V, Lambda] = eig(Qc, 'vector');   % Lambda is a vector of eigenvalues
lam = Lambda;

% Sign-preserving repair (equation 22)
sgn     = sign(lam);
sgn(sgn == 0) = 1;               % convention: sign(0) = +1
lam_prime = max(abs(lam), tau) .* sgn;

% Reconstruct regularised operator
Qc_prime = V * diag(lam_prime) * V';
Qc_prime = 0.5 * (Qc_prime + Qc_prime');   % numerical symmetry

% Condition number
kappa = max(abs(lam_prime)) / min(abs(lam_prime));

end
