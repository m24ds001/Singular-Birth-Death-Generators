function [x, Q_pp] = direct_reconstruct(Qt, b, Qc, Qc_prime, P, varargin)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% DIRECT_RECONSTRUCT  Fine-level direct reconstruction via Strategy B.
%
%   Forms the modified operator (equation 38):
%     Q'' = Qt + P (Q'_c - Qc) P' + delta * I
%
%   and solves Q'' x = b via Cholesky (if Q'' is SPD) or LU.
%   The shift delta > 0 enforces strict positive-definiteness; the
%   resulting stationary-distribution bias satisfies
%     ||pi_delta - pi*||_1 <= 2 delta / gamma_{Q''}
%   which accounts for the ~1-digit accuracy gap versus Strategy A.
%
% Usage:
%   [x, Q_pp] = direct_reconstruct(Qt, b, Qc, Qc_prime, P)
%   [x, Q_pp] = direct_reconstruct(Qt, b, Qc, Qc_prime, P, 'delta', 1e-12)
%
% Input:
%   Qt       - n x n symmetrised generator (symmetric tridiagonal)
%   b        - n x 1 right-hand side
%   Qc       - nc x nc Galerkin coarse operator (pre-repair)
%   Qc_prime - nc x nc regularised coarse operator (post-repair)
%   P        - n x nc prolongation operator
%
% Options:
%   'delta'  - shift for strict invertibility (default sqrt(eps)*||Qt||_2)
%
% Output:
%   x     - solution vector
%   Q_pp  - assembled modified operator Q'' (for diagnostic use)
%
% Reference: Section 3.5, equation (38); Table 6.

p = inputParser;
addParameter(p, 'delta', []);   % default set below
parse(p, varargin{:});
delta = p.Results.delta;

if isempty(delta)
    delta = sqrt(eps) * norm(Qt, 2);
end

% Correction term: P (Q'_c - Qc) P'
correction = P * (Qc_prime - Qc) * P';

% Modified operator Q'' = Qt + correction + delta*I
Q_pp = full(Qt) + correction + delta * eye(size(Qt, 1));
Q_pp = 0.5 * (Q_pp + Q_pp');   % ensure symmetry to machine precision

% Attempt Cholesky; fall back to LU if not SPD
[L, flag] = chol(Q_pp, 'lower');
if flag == 0
    % Cholesky succeeded
    x = L' \ (L \ b);
else
    % LU factorisation
    [Llu, Ulu, plu] = lu(Q_pp, 'vector');
    y = Llu \ b(plu);
    x = Ulu \ y;
end

end
