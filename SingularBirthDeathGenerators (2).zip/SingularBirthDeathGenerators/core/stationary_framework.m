function [pi_star, info] = stationary_framework(Q, varargin)
% STATIONARY_FRAMEWORK  Master driver for Algorithm 1.
%
%   GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
%
%   Computes the stationary distribution of a reversible birth-death Markov
%   chain whose generator Q may be exactly singular and severely ill-conditioned.
%
%   Pipeline (Section 3.1):
%     Stage 1 - Symmetrisation and Markov chain lumping (O(n))
%     Stage 2 - Spectral repair of the coarse operator (O(nc^3))
%     Stage 3 - Solve via Strategy A (PCG) or Strategy B (direct)
%     Stage 4 - Back-transformation to recover pi*
%
% Usage:
%   pi_star = stationary_framework(Q)
%   pi_star = stationary_framework(Q, 'strategy', 'A', 'tau_rel', 0.1, ...)
%   [pi_star, info] = stationary_framework(Q, ...)
%
% Input:
%   Q        - (n+1) x (n+1) generator matrix (zero row sums, off-diag >= 0)
%              Pass the original (possibly non-symmetric) generator; the
%              function forms Qt = D^{1/2} Q D^{-1/2} internally.
%
% Options (name-value pairs):
%   'strategy'  - 'A' (PCG, default) or 'B' (direct reconstruction)
%   'tau_rel'   - threshold as fraction of sigma_max(Qc) (default 0.1)
%   'pi_star'   - known stationary distribution for D (bypasses null-space solve)
%   'tol'       - PCG relative tolerance (Strategy A; default 1e-12)
%   'maxit'     - PCG max iterations (Strategy A; default 50)
%   'delta'     - stabilisation shift (Strategy B; default sqrt(eps)*||Qt||_2)
%   'verbose'   - print iteration summary (default false)
%
% Output:
%   pi_star  - stationary distribution (normalised, positive entries)
%   info     - struct with fields:
%              .kappa_Qt      condition number of Qt
%              .kappa_Qc      condition number of Qc (before repair)
%              .kappa_Qc_rep  condition number of Q'_c (after repair)
%              .tau           threshold used
%              .iter          PCG iteration count (Strategy A) or NaN
%              .res_hist      relative residual history (Strategy A)
%              .strategy      'A' or 'B'
%              .time_stage1   wall time Stage 1 (s)
%              .time_stage2   wall time Stage 2 (s)
%              .time_stage3   wall time Stage 3 (s)
%
% Reference: Algorithm 1 (Section 3.1).

%% Parse options
p = inputParser;
addParameter(p, 'strategy', 'A');
addParameter(p, 'tau_rel',  0.1);
addParameter(p, 'pi_star',  []);
addParameter(p, 'tol',      1e-12);
addParameter(p, 'abstol',   1e-14);
addParameter(p, 'maxit',    50);
addParameter(p, 'delta',    []);
addParameter(p, 'verbose',  false);
parse(p, varargin{:});
opts = p.Results;

n = size(Q, 1);

%% Stage 1: Symmetrisation and Markov chain lumping
t1 = tic;

[Qt, D, pi_ref] = symmetrise_generator(Q, opts.pi_star);

% Build bordered SPD system A_tilde_bd (equation 5):
% replace row 0 of Qt' by normalisation constraint (D^{-1/2} * 1)'
[Abd, bbd] = bordered_system(Qt, D);

% Build restriction and coarse operator
[R, P, nc] = build_restriction(n);
Qc = galerkin_coarsen(Qt, R, P);

info.time_stage1 = toc(t1);

%% Stage 2: Spectral repair
t2 = tic;

tau = opts.tau_rel * norm(Qc, 2);
[Qc_prime, ~, ~, kappa_rep] = spectral_repair(Qc, tau);

info.time_stage2 = toc(t2);

%% Stage 3: Solve
t3 = tic;

switch upper(opts.strategy)
    case 'A'
        [pi_tilde, iter, res_hist] = pcg_multiscale(Abd, bbd, Qc_prime, R, P, ...
            'tol', opts.tol, 'abstol', opts.abstol, 'maxit', opts.maxit);
        info.iter     = iter;
        info.res_hist = res_hist;
    case 'B'
        [pi_tilde, ~] = direct_reconstruct(Qt, bbd, Qc, Qc_prime, P, ...
            'delta', opts.delta);
        info.iter     = NaN;
        info.res_hist = [];
    otherwise
        error('stationary_framework: strategy must be ''A'' or ''B''.');
end

info.time_stage3 = toc(t3);

%% Stage 4: Back-transformation pi* = D^{-1/2} pi_tilde / (1' D^{-1/2} pi_tilde)
d_inv_half = diag(D).^(-1);   % entries 1/sqrt(pi_i^*)... but D = diag(sqrt(pi*))
% D = diag(sqrt(pi*)), so D^{-1/2} means diag(pi*^{-1/4})
% Recall: pi_tilde = D^{1/2} pi* so pi* = D^{-1/2} pi_tilde (Section 2.3)
sqrt_pi = diag(D);             % sqrt(pi_i^*)
pi_star = pi_tilde ./ sqrt_pi; % D^{-1/2} pi_tilde (elementwise: divide by sqrt(pi_i^*))
pi_star = pi_star / sum(pi_star);
pi_star = max(pi_star, 0);     % project to probability simplex (guard rounding)
pi_star = pi_star / sum(pi_star);

%% Diagnostics
info.kappa_Qt      = cond(Qt);
info.kappa_Qc      = cond(Qc);
info.kappa_Qc_rep  = kappa_rep;
info.tau           = tau;
info.strategy      = upper(opts.strategy);

if opts.verbose
    fprintf('--- stationary_framework ---\n');
    fprintf('  n = %d,  nc = %d\n', n, nc);
    fprintf('  kappa_2(Qt)   = %.3e\n', info.kappa_Qt);
    fprintf('  kappa_2(Qc)   = %.3e\n', info.kappa_Qc);
    fprintf('  tau           = %.3e  (%.4f * sigma_max(Qc))\n', tau, opts.tau_rel);
    fprintf('  kappa_2(Q_c'') = %.3e\n', kappa_rep);
    if strcmp(upper(opts.strategy), 'A')
        fprintf('  PCG iterations = %d\n', iter);
        fprintf('  Final rel. res = %.3e\n', res_hist(end));
    end
    fprintf('  Stage 1: %.4f s  Stage 2: %.4f s  Stage 3: %.4f s\n', ...
        info.time_stage1, info.time_stage2, info.time_stage3);
end

end
