function [R, P, nc] = build_restriction(n, varargin)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% BUILD_RESTRICTION  Construct the pairwise-averaging restriction operator R
%   and its transpose P = R'.
%
% The restriction is defined by (equation 15):
%   R_{k,i} = 1/2  if i in {2k-1, 2k}
%           = 0    otherwise
%
% For odd n, the last coarse state covers only fine state n; the last
% row of R is normalised to sqrt(1/2) so that R*R' = (1/2)*I_nc holds.
%
% Optionally, the stationary-weighted restriction R^pi (Definition 2.2)
% is returned when a stationary distribution pi_star is supplied.
%
% Usage:
%   [R, P, nc] = build_restriction(n)
%   [R, P, nc] = build_restriction(n, pi_star)   % stationary-weighted
%
% Input:
%   n        - number of fine states (matrix dimension)
%   pi_star  - (optional) stationary distribution for R^pi (Definition 2.2)
%
% Output:
%   R        - nc x n restriction operator (sparse)
%   P        - n x nc prolongation operator P = R' (sparse)
%   nc       - number of coarse states (floor(n/2) for even n)
%
% Verification:
%   norm(R*R' - 0.5*eye(nc), 'fro') should be below machine epsilon.
%
% Reference: Section 2.6, equations (15)-(16).

use_stationary = (nargin >= 2) && ~isempty(varargin{1});
if use_stationary
    pi_star = varargin{1}(:);
    pi_star = pi_star / sum(pi_star);
end

n_even = mod(n, 2) == 0;
nc     = floor((n + 1) / 2);   % ceil(n/2) but floor for 1-indexed pairs

% Build sparse restriction
rows = [];
cols = [];
vals = [];

for k = 1:nc
    i1 = 2*k - 1;
    i2 = 2*k;
    if i2 <= n
        % Standard pair
        if use_stationary
            pi_hat_k = pi_star(i1) + pi_star(i2);
            w1 = pi_star(i1) / pi_hat_k;
            w2 = pi_star(i2) / pi_hat_k;
        else
            w1 = 0.5;
            w2 = 0.5;
        end
        rows = [rows; k; k];
        cols = [cols; i1; i2];
        vals = [vals; w1; w2];
    else
        % Singleton last class (odd n): normalise for RR'=0.5*I
        if use_stationary
            w1 = 1.0;  % only one state in class; R^pi_{k,i1} = 1
        else
            w1 = sqrt(0.5);  % normalise so R_{k,i1}^2 = 0.5
        end
        rows = [rows; k];
        cols = [cols; i1];
        vals = [vals; w1];
    end
end

R = sparse(rows, cols, vals, nc, n);
P = R';

% Verify R*R' = (1/2)*I_nc for the pairwise-averaging (non-stationary) case
if ~use_stationary
    RRT_err = norm(R*R' - 0.5*speye(nc), 'fro');
    assert(RRT_err < 1e-12, ...
        'build_restriction: RR^T identity violated; error = %.2e', RRT_err);
end

end
