function [Qt, D, pi_star] = symmetrise_generator(Q, varargin)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% SYMMETRISE_GENERATOR  Form the similarity-transformed generator
%   Qt = D^{1/2} * Q * D^{-1/2}
%
% For a reversible birth-death chain with exact geometric stationary
% distribution (M/M/1/n), D is formed from the closed-form formula.
% For general chains, the stationary distribution is computed by the
% null-space of Q' and supplied as an optional input.
%
% Usage:
%   [Qt, D, pi_star] = symmetrise_generator(Q)
%   [Qt, D, pi_star] = symmetrise_generator(Q, pi_star)
%
% Input:
%   Q        - (n+1)x(n+1) generator matrix (zero row sums, off-diag >= 0)
%   pi_star  - (optional) stationary distribution vector (column, sum=1)
%
% Output:
%   Qt       - Symmetrised generator D^{1/2}*Q*D^{-1/2} (symmetric tridiagonal)
%   D        - Diagonal matrix diag(sqrt(pi_star))
%   pi_star  - Stationary distribution used
%
% Reference: Section 2.2, equation (2).

n = size(Q, 1);

if nargin >= 2 && ~isempty(varargin{1})
    pi_star = varargin{1};
    pi_star = pi_star(:);
    pi_star = pi_star / sum(pi_star);
else
    % Compute null vector of Q' by power iteration on the stochastic matrix
    % formed from Q; safe for near-singular generators.
    [~, ~, V] = svds(Q', 1, 'smallest');
    pi_star = abs(V(:,1));
    pi_star = pi_star / sum(pi_star);
end

% Guard against near-zero entries in the stationary distribution
tol_zero = 1e-300;
if any(pi_star < tol_zero)
    warning('symmetrise_generator:nearZero', ...
        'Some stationary probabilities are below %.2e; D may be ill-formed.', ...
        tol_zero);
    pi_star = max(pi_star, tol_zero);
    pi_star = pi_star / sum(pi_star);
end

d      = sqrt(pi_star);           % vector of sqrt(pi_i^*)
d_inv  = 1 ./ sqrt(pi_star);      % vector of 1/sqrt(pi_i^*)
D      = diag(d);

% Similarity transformation: Qt_{ij} = sqrt(pi_i^*) / sqrt(pi_j^*) * Q_{ij}
Qt = bsxfun(@times, d, bsxfun(@times, Q, d_inv'));

% Symmetry check
sym_err = norm(Qt - Qt', 'fro') / (norm(Qt, 'fro') + eps);
if sym_err > 1e-10
    warning('symmetrise_generator:asymmetric', ...
        'Symmetry residual ||Qt - Qt^T||_F/||Qt||_F = %.2e; chain may not be reversible.', ...
        sym_err);
end

end
