function [x, iter, res_hist] = pcg_multiscale(A, b, Qc_prime, R, P, varargin)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% PCG_MULTISCALE  Preconditioned conjugate gradient solve using the
%   multiscale preconditioner M^{-1} r = 2 P (Q'_c)^{-1} R r.
%
%   The factor 2 compensates for R R' = (1/2) I_nc (Lemma 3.4).
%   Applied to the bordered SPD system A_tilde_bd (equation 5),
%   this preconditioner satisfies (Corollary 3.5):
%     k < 9  (even n, uniform rates, tau = 0.1 sigma_max(Qc), eps_rel = 1e-12)
%
% Usage:
%   [x, iter, res_hist] = pcg_multiscale(A, b, Qc_prime, R, P)
%   [x, iter, res_hist] = pcg_multiscale(A, b, Qc_prime, R, P, 'tol', 1e-12, 'maxit', 50)
%
% Input:
%   A        - n x n symmetric positive definite coefficient matrix
%   b        - n x 1 right-hand side
%   Qc_prime - nc x nc regularised coarse operator (output of spectral_repair)
%   R        - nc x n restriction operator
%   P        - n x nc prolongation operator (P = R')
%
% Options (name-value pairs):
%   'tol'    - relative residual tolerance (default 1e-12)
%   'abstol' - absolute residual tolerance (default 1e-14)
%   'maxit'  - maximum number of PCG iterations (default 50)
%   'x0'     - initial guess (default zeros)
%
% Output:
%   x        - solution vector
%   iter     - number of iterations performed
%   res_hist - vector of relative residual norms ||r_k|| / ||b||
%
% Reference: Section 3.5, equation (37); Lemma 3.4; Corollary 3.5.

% Parse options
p = inputParser;
addParameter(p, 'tol',   1e-12);
addParameter(p, 'abstol',1e-14);
addParameter(p, 'maxit', 50);
addParameter(p, 'x0',    []);
parse(p, varargin{:});
tol    = p.Results.tol;
abstol = p.Results.abstol;
maxit  = p.Results.maxit;
x0     = p.Results.x0;

n = length(b);
if isempty(x0)
    x = zeros(n, 1);
else
    x = x0(:);
end

% Factorise Q'_c once (dense nc x nc, nc = n/2)
[L_c, flag_c] = chol(Qc_prime, 'lower');
if flag_c ~= 0
    % Q'_c may not be SPD (e.g., has negative eigenvalues for a generator);
    % fall back to LU factorisation of Q'_c
    [L_c, U_c, perm_c] = lu(Qc_prime, 'vector');
    use_lu = true;
else
    use_lu = false;
end

% Preconditioner application: M^{-1} r = 2 P (Q'_c)^{-1} R r
    function Mrinv = apply_preconditioner(r)
        Rr = R * r;                        % restriction
        if use_lu
            y  = L_c \ Rr(perm_c);
            y  = U_c \ y;
        else
            y  = L_c \ Rr;
            y  = L_c' \ y;
        end
        Mrinv = 2 * (P * y);               % prolongation with factor 2
    end

% PCG iteration
r       = b - A * x;
norm_b  = norm(b);
if norm_b < eps
    norm_b = 1;
end

z       = apply_preconditioner(r);
p_dir   = z;
rz      = r' * z;

res_hist = zeros(maxit + 1, 1);
res_hist(1) = norm(r) / norm_b;

for iter = 1:maxit
    Ap    = A * p_dir;
    alpha = rz / (p_dir' * Ap);
    x     = x + alpha * p_dir;
    r     = r - alpha * Ap;

    rel_res = norm(r) / norm_b;
    res_hist(iter + 1) = rel_res;

    if rel_res <= tol || norm(r) <= abstol
        break;
    end

    z_new  = apply_preconditioner(r);
    rz_new = r' * z_new;
    beta   = rz_new / rz;
    p_dir  = z_new + beta * p_dir;
    rz     = rz_new;
    z      = z_new;
end

res_hist = res_hist(1:iter + 1);

end
