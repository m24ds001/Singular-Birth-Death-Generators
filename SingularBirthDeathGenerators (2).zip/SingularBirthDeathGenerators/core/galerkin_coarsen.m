function Qc = galerkin_coarsen(Qt, R, P)
% GitHub: https://github.com/m24ds001/Singular-Birth-Death-Generators
% GALERKIN_COARSEN  Compute the Galerkin coarse-grid operator
%   Qc = R * Qt * P   (equation 17)
%
% For tridiagonal Qt and the pairwise-averaging R, the triple product costs
% O(n) arithmetic operations by exploiting the tridiagonal sparsity pattern.
%
% Input:
%   Qt  - n x n symmetric tridiagonal generator (sparse or full)
%   R   - nc x n restriction operator
%   P   - n x nc prolongation operator (P = R')
%
% Output:
%   Qc  - nc x nc Galerkin coarse operator (symmetric by Theorem 2.3)
%
% Properties guaranteed:
%   (a) Qc is symmetric (Theorem 2.3)
%   (b) spec(Qc) subset [lambda_min(Qt), 0] (Theorem 2.4)
%   (c) 0 in spec(Qc) for even n (Theorem 2.4)
%   (d) For uniform rates, Qc == Kemeny-Snell lumped generator (Theorem 2.5)
%
% Reference: Definition 2.1 (Section 2.6).

Qc = full(R * Qt * P);

% Symmetrise to machine precision (should be symmetric to ~eps*||Qc||)
Qc = 0.5 * (Qc + Qc');

end
