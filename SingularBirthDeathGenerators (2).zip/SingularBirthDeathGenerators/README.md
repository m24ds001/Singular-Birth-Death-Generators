# Singular Birth–Death Generators: Preconditioned Iterative Framework

**GitHub repository:** https://github.com/m24ds001/Singular-Birth-Death-Generators

MATLAB implementation accompanying the manuscript:

> **A Preconditioned Iterative Framework for Singular Birth–Death Generators:
> Condition Bounds via Markov Chain Lumping**
> Renikunta Ramesh and Ramsha Mehreen,
> Kakatiya Institute of Technology and Science, Warangal, India.

---

## Repository Structure

```
SingularBirthDeathGenerators/
├── core/
│   ├── symmetrise_generator.m       % Form Q_tilde = D^{1/2} Q D^{-1/2}
│   ├── build_restriction.m          % Pairwise-averaging restriction R (eq. 15)
│   ├── galerkin_coarsen.m           % Galerkin coarse operator Qc = R*Qt*R' (eq. 17)
│   ├── spectral_repair.m            % Sign-preserving eigenvalue regularisation (Alg. 2)
│   ├── pcg_multiscale.m             % Multiscale PCG solve (Strategy A)
│   ├── direct_reconstruct.m         % Direct fine-level reconstruction (Strategy B)
│   └── stationary_framework.m      % Master driver: Algorithm 1
├── experiments/
│   ├── mmn_queue.m                  % M/M/1/n stationary distribution (Sec. 4.1.1)
│   ├── paulsson_model.m             % Gene-expression noise model (Sec. 4.1.2)
│   ├── lacz_validation.m            % E. coli lacZ validation (Sec. 4.1.3)
│   ├── logistic_growth.m            % Logistic population-growth model (Sec. 4.1.4)
│   ├── synthetic_benchmark.m        % Parametric family A_{delta} (Sec. 4.2)
│   ├── coarsening_ablation.m        % Coarsening ratio ablation (Sec. 4.5)
│   └── threshold_sensitivity.m     % Threshold tau sensitivity (Sec. 4.6)
├── figures/
│   ├── generate_fig1.m              % Figure 1: kappa_2(Q) vs rho
│   ├── generate_fig2.m              % Figure 2: PCG residual histories
│   └── generate_fig3.m              % Figure 3: PCG iterations vs n
├── utils/
│   ├── mmn_generator.m              % Build M/M/1/n generator Q (eq. 9)
│   ├── stationary_geometric.m       % Exact geometric stationary distribution
│   ├── bordered_system.m            % Assemble bordered SPD system (eq. 5)
│   ├── tikhonov_solve.m             % Tikhonov regularised solve (baseline)
│   ├── recurrence_solve.m           % Detailed-balance recurrence (eq. 7)
│   ├── condition_number_asymptotic.m % Asymptotic kappa_2 formula (eq. 12)
│   └── select_stations.m            % NOAA station selection utility
└── tests/
    ├── test_restriction_identity.m  % Verify RR' = (1/2)I (eq. 16)
    ├── test_lemma31.m               % Verify sigma_max(Qc) <= ||Qt||_2/2
    ├── test_theorem32.m             % Verify kappa_2(Q'c) <= sigma_max(Qc)/tau
    ├── test_theorem38.m             % Verify minimal perturbation (Table 20)
    ├── test_galerkin_lumping.m      % Verify Thm 2.5: Galerkin == Kemeny-Snell
    └── run_all_tests.m              % Run full test suite
```

## Requirements

- MATLAB R2020a or later (tested on R2024a)
- Statistics and Machine Learning Toolbox (for `chi2inv` in threshold selection)
- Intel MKL BLAS recommended; Accelerate BLAS (Apple M-series) also verified

## Quick Start

```matlab
% Reproduce Table 9 (near-critical M/M/1/n results)
cd experiments
mmn_queue

% Reproduce Figure 1
cd figures
generate_fig1

% Run all unit tests
cd tests
run_all_tests
```

## Algorithm Overview

The framework operates on the symmetrised generator Q_tilde = D^{1/2} Q D^{-1/2}
through four stages:

1. **Markov chain lumping** — form Qc = R * Q_tilde * R' via pairwise-averaging restriction
2. **Spectral repair** — sign-preserving eigenvalue regularisation of Qc (Algorithm 2)
3. **Solution strategy** — Strategy A (PCG with multiscale preconditioner) or B (direct)
4. **Back-transformation** — recover pi* = D^{-1/2} pi_tilde / (1' D^{-1/2} pi_tilde)

Key identity: R*R' = (1/2)*I drives the implication chain
  sigma_max(Qc) <= ||Q_tilde||_2 / 2  =>  kappa_2(Q'c) <= sigma_max(Qc)/tau  =>  k < 9

## Data Sources

- NOAA GHCN-Daily: https://www.ncei.noaa.gov/products/land-based-station/global-historical-climatology-network-daily
- UCI Gas Sensor dataset: https://archive.ics.uci.edu/ml/datasets/gas+sensor+array+under+dynamic+gas+mixtures
- lacZ mRNA histogram: digitised from Figure 1C of Golding et al. (2005), Cell 123(6).

## Citation

```
@article{ramesh2026preconditioned,
  title   = {A Preconditioned Iterative Framework for Singular Birth--Death
             Generators: Condition Bounds via {Markov} Chain Lumping},
  author  = {Ramesh, Renikunta and Mehreen, Ramsha},
  journal = {Journal of Applied Mathematics and Computing},
  year    = {2026},
  url     = {https://github.com/m24ds001/Singular-Birth-Death-Generators}
}
```

## Repository URL

https://github.com/m24ds001/Singular-Birth-Death-Generators

## License

MIT License. See LICENSE for details.
